package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ChatViewModel
import com.example.util.FileUtils

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: ChatViewModel = viewModel()
            val currentUser by viewModel.currentUser.collectAsState()
            val settings by viewModel.settings.collectAsState()
            val conversations by viewModel.conversations.collectAsState()
            val isAuthLoading by viewModel.isAuthLoading.collectAsState()
            val authError by viewModel.authError.collectAsState()

            var isShowingSettings by remember { mutableStateOf(false) }

            // Voice permission launcher
            val recordAudioLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { isGranted ->
                if (isGranted) {
                    viewModel.toggleVoiceInput()
                } else {
                    Toast.makeText(this, "Microphone permission is required for voice input", Toast.LENGTH_SHORT).show()
                }
            }

            MyApplicationTheme(themeMode = settings.themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (currentUser == null) {
                        AuthScreen(
                            onLogin = { email, pass -> viewModel.login(email, pass) },
                            onSignUp = { name, email, pass -> viewModel.signUp(name, email, pass) },
                            onContinueWithGoogle = { viewModel.continueWithGoogle() },
                            isLoading = isAuthLoading,
                            errorMessage = authError
                        )
                    } else if (isShowingSettings) {
                        SettingsScreen(
                            currentUser = currentUser,
                            settings = settings,
                            conversationCount = conversations.size,
                            onBack = { isShowingSettings = false },
                            onUpdateName = { viewModel.updateUserName(it) },
                            onChangePassword = { viewModel.changePassword(it) },
                            onSetThemeMode = { viewModel.setThemeMode(it) },
                            onSetDefaultModel = { viewModel.setDefaultModel(it) },
                            onSetResponseLanguage = { viewModel.setResponseLanguage(it) },
                            onSetStreamingEnabled = { viewModel.setStreamingEnabled(it) },
                            onSetVoiceLanguage = { viewModel.setVoiceLanguage(it) },
                            onSetSpeechRate = { viewModel.setSpeechRate(it) },
                            onClearAllHistory = { viewModel.clearAllHistory() },
                            onExportHistory = {
                                viewModel.exportChatHistory { text ->
                                    FileUtils.shareText(this, text, "SAMADHAN AI - All Chats")
                                }
                            },
                            onLogout = {
                                viewModel.logout()
                                isShowingSettings = false
                            },
                            onDeleteAccount = {
                                viewModel.deleteAccount()
                                isShowingSettings = false
                            },
                            onTestTts = { viewModel.testTts() }
                        )
                    } else {
                        ChatScreen(
                            viewModel = viewModel,
                            onOpenSettings = { isShowingSettings = true }
                        )
                    }
                }
            }
        }
    }
}
