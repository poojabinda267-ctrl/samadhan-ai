package com.example.ai

data class AiModelInfo(
    val id: String,
    val displayName: String,
    val tag: String,
    val description: String,
    val iconName: String = "auto_awesome"
)

object AiModels {
    val PRIMARY = AiModelInfo(
        id = "default",
        displayName = "SAMADHAN AI",
        tag = "Standard",
        description = "Intelligent solution-oriented AI assistant for reasoning, code assistance, and solutions."
    )

    val ADVANCED = AiModelInfo(
        id = "reasoning",
        displayName = "SAMADHAN Pro",
        tag = "Deep Reasoning",
        description = "Advanced logical reasoning, complex problem solving, and solutions."
    )

    val FAST = AiModelInfo(
        id = "fast",
        displayName = "SAMADHAN Fast",
        tag = "Low-Latency",
        description = "Instant responses for rapid conversations and quick solutions."
    )

    val IMAGE_GEN = AiModelInfo(
        id = "image",
        displayName = "SAMADHAN Vision Creator",
        tag = "Image Studio",
        description = "Generates custom illustrations and images from prompts."
    )

    val AVAILABLE_MODELS = listOf(PRIMARY, ADVANCED, FAST)
}
