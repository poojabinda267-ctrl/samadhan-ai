package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class AiResult {
    data class Success(val text: String, val imageUri: String? = null) : AiResult()
    data class Error(val message: String) : AiResult()
}

class GeminiService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(90, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .build()

    private val n8nWebhookUrl = "https://sukhdav.app.n8n.cloud/webhook/samadhan-ai"

    suspend fun generateResponse(
        prompt: String,
        modelId: String = "n8n-samadhan-ai",
        conversationHistory: List<Pair<String, String>> = emptyList(),
        imageBitmap: Bitmap? = null,
        fileContent: String? = null,
        responseLanguage: String = "auto"
    ): AiResult = withContext(Dispatchers.IO) {
        val userMessage = buildFinalMessage(prompt, fileContent)

        val requestJson = JSONObject().apply {
            put("message", userMessage)
        }

        val request = Request.Builder()
            .url(n8nWebhookUrl)
            .addHeader("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            val response: Response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val extractedText = extractResponseText(responseBody)
                if (!extractedText.isNullOrEmpty()) {
                    return@withContext AiResult.Success(extractedText)
                } else {
                    return@withContext AiResult.Error("No 'response' field found in webhook output: $responseBody")
                }
            } else {
                val errorMessage = extractErrorMessage(response.code, responseBody)
                return@withContext AiResult.Error(errorMessage)
            }
        } catch (e: IOException) {
            return@withContext AiResult.Error("Connection to n8n webhook failed: ${e.localizedMessage ?: e.message}")
        } catch (e: Exception) {
            return@withContext AiResult.Error("Error: ${e.localizedMessage ?: e.message}")
        }
    }

    fun streamResponse(
        prompt: String,
        modelId: String = "n8n-samadhan-ai",
        conversationHistory: List<Pair<String, String>> = emptyList(),
        imageBitmap: Bitmap? = null,
        fileContent: String? = null,
        responseLanguage: String = "auto"
    ): Flow<String> = flow {
        when (val result = generateResponse(prompt, modelId, conversationHistory, imageBitmap, fileContent, responseLanguage)) {
            is AiResult.Success -> {
                emit(result.text)
            }
            is AiResult.Error -> {
                emit(result.message)
            }
        }
    }.flowOn(Dispatchers.IO)

    suspend fun generateAiImage(
        prompt: String
    ): AiResult = withContext(Dispatchers.IO) {
        generateResponse(prompt)
    }

    private fun buildFinalMessage(prompt: String, fileContent: String?): String {
        return if (!fileContent.isNullOrBlank()) {
            "File Content:\n$fileContent\n\n$prompt"
        } else {
            prompt
        }
    }

    private fun extractResponseText(responseBody: String): String? {
        try {
            val trimmed = responseBody.trim()
            if (trimmed.startsWith("{")) {
                val json = JSONObject(trimmed)
                if (json.has("response")) {
                    val resp = json.opt("response")
                    if (resp is String) return resp
                    if (resp is JSONObject && resp.has("text")) return resp.getString("text")
                    return resp?.toString()
                }
                if (json.has("output")) {
                    return json.optString("output")
                }
                if (json.has("text")) {
                    return json.optString("text")
                }
                if (json.has("message")) {
                    return json.optString("message")
                }
            } else if (trimmed.startsWith("[")) {
                val array = JSONArray(trimmed)
                if (array.length() > 0) {
                    val first = array.opt(0)
                    if (first is JSONObject) {
                        if (first.has("response")) return first.optString("response")
                        if (first.has("output")) return first.optString("output")
                        if (first.has("text")) return first.optString("text")
                        if (first.has("message")) return first.optString("message")
                    } else {
                        return first?.toString()
                    }
                }
            } else if (trimmed.isNotEmpty()) {
                return trimmed
            }
        } catch (_: Exception) {}
        return null
    }

    private fun extractErrorMessage(statusCode: Int, responseBody: String): String {
        try {
            val trimmed = responseBody.trim()
            if (trimmed.startsWith("{")) {
                val json = JSONObject(trimmed)
                if (json.has("message")) {
                    return "n8n Webhook Error: ${json.getString("message")} (HTTP $statusCode)"
                }
                if (json.has("error")) {
                    return "n8n Webhook Error: ${json.getString("error")} (HTTP $statusCode)"
                }
            }
            if (trimmed.isNotEmpty()) {
                return "n8n Webhook Error (HTTP $statusCode): $trimmed"
            }
        } catch (_: Exception) {}
        return "n8n Webhook Error (HTTP $statusCode)"
    }
}
