package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val email: String,
    val passwordHash: String = "",
    val profilePicture: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "conversations")
data class Conversation(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val conversationId: String,
    val role: String, // "user" or "assistant"
    val content: String,
    val attachmentsJson: String? = null, // JSON list of Attachment
    val modelUsed: String = "gemini-3.5-flash",
    val isImageGeneration: Boolean = false,
    val generatedImageUri: String? = null,
    val liked: Boolean? = null, // true = like, false = dislike, null = none
    val createdAt: Long = System.currentTimeMillis()
)

data class Attachment(
    val type: String, // "image" or "file"
    val name: String,
    val mimeType: String,
    val uriString: String? = null,
    val base64Data: String? = null,
    val textContent: String? = null,
    val sizeBytes: Long = 0L
)
