package com.example.data.pref

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "samadhan_prefs")

data class AppSettings(
    val currentUserId: String? = null,
    val themeMode: String = "system", // "system", "light", "dark"
    val defaultModel: String = "gemini-3.5-flash",
    val responseLanguage: String = "auto", // "auto", "hi", "en"
    val streamingEnabled: Boolean = true,
    val voiceLanguage: String = "hi-IN", // "hi-IN" or "en-US"
    val speechRate: Float = 1.0f
)

class UserPreferences(private val context: Context) {
    companion object {
        private val KEY_USER_ID = stringPreferencesKey("user_id")
        private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        private val KEY_DEFAULT_MODEL = stringPreferencesKey("default_model")
        private val KEY_RESPONSE_LANG = stringPreferencesKey("response_lang")
        private val KEY_STREAMING = booleanPreferencesKey("streaming_enabled")
        private val KEY_VOICE_LANG = stringPreferencesKey("voice_lang")
        private val KEY_SPEECH_RATE = floatPreferencesKey("speech_rate")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            currentUserId = prefs[KEY_USER_ID],
            themeMode = prefs[KEY_THEME_MODE] ?: "system",
            defaultModel = prefs[KEY_DEFAULT_MODEL] ?: "gemini-3.5-flash",
            responseLanguage = prefs[KEY_RESPONSE_LANG] ?: "auto",
            streamingEnabled = prefs[KEY_STREAMING] ?: true,
            voiceLanguage = prefs[KEY_VOICE_LANG] ?: "hi-IN",
            speechRate = prefs[KEY_SPEECH_RATE] ?: 1.0f
        )
    }

    suspend fun setUserId(userId: String?) {
        context.dataStore.edit { prefs ->
            if (userId != null) {
                prefs[KEY_USER_ID] = userId
            } else {
                prefs.remove(KEY_USER_ID)
            }
        }
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { prefs -> prefs[KEY_THEME_MODE] = mode }
    }

    suspend fun setDefaultModel(model: String) {
        context.dataStore.edit { prefs -> prefs[KEY_DEFAULT_MODEL] = model }
    }

    suspend fun setResponseLanguage(lang: String) {
        context.dataStore.edit { prefs -> prefs[KEY_RESPONSE_LANG] = lang }
    }

    suspend fun setStreamingEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[KEY_STREAMING] = enabled }
    }

    suspend fun setVoiceLanguage(lang: String) {
        context.dataStore.edit { prefs -> prefs[KEY_VOICE_LANG] = lang }
    }

    suspend fun setSpeechRate(rate: Float) {
        context.dataStore.edit { prefs -> prefs[KEY_SPEECH_RATE] = rate }
    }
}
