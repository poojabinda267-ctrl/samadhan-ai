package com.example.data.repository

import com.example.data.db.UserDao
import com.example.data.model.User
import com.example.data.pref.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import java.util.UUID

sealed class AuthResult {
    data class Success(val user: User) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class AuthRepository(
    private val userDao: UserDao,
    private val userPreferences: UserPreferences
) {

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val currentUserFlow: Flow<User?> = userPreferences.settingsFlow.flatMapLatest { prefs ->
        val userId = prefs.currentUserId
        if (userId != null) {
            userDao.getUserById(userId)
        } else {
            flowOf(null)
        }
    }

    suspend fun loginWithEmail(email: String, password: String): AuthResult {
        val trimmedEmail = email.trim().lowercase()
        if (trimmedEmail.isEmpty() || password.isEmpty()) {
            return AuthResult.Error("Please enter both email and password")
        }

        val existingUser = userDao.getUserByEmail(trimmedEmail)
        return if (existingUser != null) {
            if (existingUser.passwordHash.isEmpty() || existingUser.passwordHash == password) {
                userPreferences.setUserId(existingUser.id)
                AuthResult.Success(existingUser)
            } else {
                AuthResult.Error("Incorrect password. Please try again.")
            }
        } else {
            AuthResult.Error("No account found with this email. Please sign up.")
        }
    }

    suspend fun signUpWithEmail(name: String, email: String, password: String): AuthResult {
        val trimmedEmail = email.trim().lowercase()
        val trimmedName = name.trim()
        if (trimmedName.isEmpty()) return AuthResult.Error("Please enter your name")
        if (trimmedEmail.isEmpty() || !trimmedEmail.contains("@")) return AuthResult.Error("Please enter a valid email")
        if (password.length < 6) return AuthResult.Error("Password must be at least 6 characters")

        val existingUser = userDao.getUserByEmail(trimmedEmail)
        if (existingUser != null) {
            return AuthResult.Error("An account with this email already exists")
        }

        val newUser = User(
            id = UUID.randomUUID().toString(),
            name = trimmedName,
            email = trimmedEmail,
            passwordHash = password,
            profilePicture = ""
        )
        userDao.insertUser(newUser)
        userPreferences.setUserId(newUser.id)
        return AuthResult.Success(newUser)
    }

    suspend fun continueWithGoogle(userEmail: String = "poojabinda267@gmail.com", userName: String = "Pooja Binda"): AuthResult {
        val trimmedEmail = userEmail.lowercase()
        var user = userDao.getUserByEmail(trimmedEmail)
        if (user == null) {
            user = User(
                id = UUID.randomUUID().toString(),
                name = userName,
                email = trimmedEmail,
                passwordHash = "",
                profilePicture = ""
            )
            userDao.insertUser(user)
        }
        userPreferences.setUserId(user.id)
        return AuthResult.Success(user)
    }

    suspend fun updateUserProfile(userId: String, name: String, profilePicture: String) {
        val existing = userDao.getUserByEmail("") // or update directly
        userDao.updateUser(User(id = userId, name = name, email = "", profilePicture = profilePicture))
    }

    suspend fun changePassword(user: User, newPass: String): Boolean {
        if (newPass.length < 6) return false
        userDao.updateUser(user.copy(passwordHash = newPass))
        return true
    }

    suspend fun updateName(user: User, newName: String) {
        if (newName.isNotBlank()) {
            userDao.updateUser(user.copy(name = newName.trim()))
        }
    }

    suspend fun logout() {
        userPreferences.setUserId(null)
    }

    suspend fun deleteAccount(userId: String) {
        userDao.deleteUser(userId)
        userPreferences.setUserId(null)
    }
}
