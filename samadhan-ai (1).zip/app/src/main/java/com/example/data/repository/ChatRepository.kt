package com.example.data.repository

import com.example.data.db.ConversationDao
import com.example.data.db.MessageDao
import com.example.data.model.Conversation
import com.example.data.model.Message
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ChatRepository(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao
) {

    fun getConversations(userId: String): Flow<List<Conversation>> {
        return conversationDao.getConversationsByUser(userId)
    }

    fun searchConversations(userId: String, query: String): Flow<List<Conversation>> {
        return conversationDao.searchConversations(userId, query)
    }

    suspend fun getConversationById(id: String): Conversation? {
        return conversationDao.getConversationById(id)
    }

    suspend fun createConversation(userId: String, title: String): Conversation {
        val conv = Conversation(
            id = UUID.randomUUID().toString(),
            userId = userId,
            title = title.take(50),
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        conversationDao.insertConversation(conv)
        return conv
    }

    suspend fun updateConversationTitle(conversationId: String, title: String) {
        conversationDao.updateTitle(conversationId, title.trim())
    }

    suspend fun deleteConversation(conversationId: String) {
        messageDao.deleteByConversation(conversationId)
        conversationDao.deleteConversation(conversationId)
    }

    suspend fun deleteAllConversations(userId: String) {
        conversationDao.deleteAllByUser(userId)
    }

    fun getMessages(conversationId: String): Flow<List<Message>> {
        return messageDao.getMessagesByConversation(conversationId)
    }

    suspend fun insertMessage(message: Message) {
        messageDao.insertMessage(message)
        // Also touch conversation updatedAt
        conversationDao.updateTitle(
            id = message.conversationId,
            title = (conversationDao.getConversationById(message.conversationId)?.title ?: "Chat"),
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun updateMessage(message: Message) {
        messageDao.updateMessage(message)
    }

    suspend fun updateMessageContent(id: String, content: String) {
        messageDao.updateContent(id, content)
    }

    suspend fun updateMessageLiked(id: String, liked: Boolean?) {
        messageDao.updateLiked(id, liked)
    }

    suspend fun deleteMessage(id: String) {
        messageDao.deleteMessage(id)
    }
}
