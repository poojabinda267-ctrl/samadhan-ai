package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MarkdownText(
    text: String,
    modifier: Modifier = Modifier,
    textColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Column(modifier = modifier) {
        val lines = text.split("\n")
        var inCodeBlock = false
        var codeLanguage = ""
        val codeBlockLines = mutableListOf<String>()

        var inTable = false
        val tableLines = mutableListOf<String>()

        var i = 0
        while (i < lines.size) {
            val line = lines[i]

            // Handle code block
            if (line.trim().startsWith("```")) {
                if (inCodeBlock) {
                    // Close code block
                    CodeBlockView(
                        code = codeBlockLines.joinToString("\n"),
                        language = codeLanguage,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                    codeBlockLines.clear()
                    inCodeBlock = false
                    codeLanguage = ""
                } else {
                    inCodeBlock = true
                    codeLanguage = line.trim().removePrefix("```").trim()
                }
                i++
                continue
            }

            if (inCodeBlock) {
                codeBlockLines.add(line)
                i++
                continue
            }

            // Handle Tables
            if (line.trim().startsWith("|") && line.trim().endsWith("|")) {
                inTable = true
                tableLines.add(line)
                i++
                continue
            } else if (inTable) {
                RenderSimpleTable(tableLines, textColor)
                tableLines.clear()
                inTable = false
            }

            // Headings
            when {
                line.startsWith("### ") -> {
                    Text(
                        text = line.removePrefix("### "),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        ),
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }
                line.startsWith("## ") -> {
                    Text(
                        text = line.removePrefix("## "),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        ),
                        modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
                    )
                }
                line.startsWith("# ") -> {
                    Text(
                        text = line.removePrefix("# "),
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        ),
                        modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
                    )
                }
                line.startsWith("> ") -> {
                    // Blockquote
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                RoundedCornerShape(4.dp)
                            )
                            .padding(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(20.dp)
                                .background(MaterialTheme.colorScheme.secondary)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = parseInlineMarkdown(line.removePrefix("> "), textColor),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontStyle = FontStyle.Italic,
                                color = textColor.copy(alpha = 0.9f)
                            )
                        )
                    }
                }
                line.trim().startsWith("- ") || line.trim().startsWith("* ") -> {
                    // Bullet list item
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp, horizontal = 4.dp)
                    ) {
                        Text(
                            text = "•",
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        val content = line.trim().removePrefix("- ").removePrefix("* ")
                        Text(
                            text = parseInlineMarkdown(content, textColor),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = textColor,
                                lineHeight = 20.sp
                            )
                        )
                    }
                }
                Regex("^\\d+\\.\\s.*").matches(line.trim()) -> {
                    // Numbered list item
                    val dotIndex = line.indexOf(".")
                    val number = line.substring(0, dotIndex + 1).trim()
                    val content = line.substring(dotIndex + 1).trim()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp, horizontal = 4.dp)
                    ) {
                        Text(
                            text = number,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                        Text(
                            text = parseInlineMarkdown(content, textColor),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = textColor,
                                lineHeight = 20.sp
                            )
                        )
                    }
                }
                line.isBlank() -> {
                    Spacer(modifier = Modifier.height(6.dp))
                }
                else -> {
                    Text(
                        text = parseInlineMarkdown(line, textColor),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = textColor,
                            lineHeight = 21.sp
                        ),
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }

            i++
        }

        if (inCodeBlock && codeBlockLines.isNotEmpty()) {
            CodeBlockView(
                code = codeBlockLines.joinToString("\n"),
                language = codeLanguage,
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }

        if (inTable && tableLines.isNotEmpty()) {
            RenderSimpleTable(tableLines, textColor)
        }
    }
}

@Composable
fun RenderSimpleTable(rows: List<String>, textColor: Color) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(6.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
    ) {
        val filtered = rows.filter { !it.contains("---") }
        filtered.forEachIndexed { index, row ->
            val cols = row.split("|").map { it.trim() }.filter { it.isNotEmpty() }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (index == 0) MaterialTheme.colorScheme.surfaceVariant
                        else MaterialTheme.colorScheme.surface
                    )
                    .padding(8.dp)
            ) {
                cols.forEach { col ->
                    Text(
                        text = col,
                        modifier = Modifier.weight(1f),
                        fontWeight = if (index == 0) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 12.sp,
                        color = textColor
                    )
                }
            }
        }
    }
}

fun parseInlineMarkdown(text: String, defaultColor: Color): androidx.compose.ui.text.AnnotatedString {
    return buildAnnotatedString {
        var cursor = 0
        while (cursor < text.length) {
            val boldStart = text.indexOf("**", cursor)
            val codeStart = text.indexOf("`", cursor)

            val nextSpecial = when {
                boldStart != -1 && codeStart != -1 -> minOf(boldStart, codeStart)
                boldStart != -1 -> boldStart
                codeStart != -1 -> codeStart
                else -> -1
            }

            if (nextSpecial == -1) {
                append(text.substring(cursor))
                break
            }

            if (nextSpecial > cursor) {
                append(text.substring(cursor, nextSpecial))
            }

            if (nextSpecial == boldStart) {
                val boldEnd = text.indexOf("**", boldStart + 2)
                if (boldEnd != -1) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = defaultColor)) {
                        append(text.substring(boldStart + 2, boldEnd))
                    }
                    cursor = boldEnd + 2
                } else {
                    append("**")
                    cursor = boldStart + 2
                }
            } else if (nextSpecial == codeStart) {
                val codeEnd = text.indexOf("`", codeStart + 1)
                if (codeEnd != -1) {
                    withStyle(
                        SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            background = Color(0x1F808080),
                            fontSize = 12.sp
                        )
                    ) {
                        append(" " + text.substring(codeStart + 1, codeEnd) + " ")
                    }
                    cursor = codeEnd + 1
                } else {
                    append("`")
                    cursor = codeStart + 1
                }
            }
        }
    }
}
