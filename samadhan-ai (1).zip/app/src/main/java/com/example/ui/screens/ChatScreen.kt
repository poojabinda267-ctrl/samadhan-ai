package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.Composer
import com.example.ui.components.MessageBubble
import com.example.ui.components.SidebarDrawer
import com.example.ui.components.SuggestionCards
import com.example.ui.components.TopNavBar
import com.example.ui.viewmodel.ChatViewModel
import com.example.util.FileUtils
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val currentUser by viewModel.currentUser.collectAsState()
    val conversations by viewModel.conversations.collectAsState()
    val currentConversation by viewModel.currentConversation.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val settings by viewModel.settings.collectAsState()

    val inputPrompt by viewModel.inputPrompt.collectAsState()
    val attachedItems by viewModel.attachedItems.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val isImageMode by viewModel.isImageMode.collectAsState()
    val isListeningVoice by viewModel.isListeningVoice.collectAsState()
    val isSpeaking by viewModel.isTtsSpeaking.collectAsState()
    val speakingMessageId by viewModel.speakingMessageId.collectAsState()

    val listState = rememberLazyListState()

    // Auto-scroll to bottom when messages update
    LaunchedEffect(messages.size, isGenerating) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                SidebarDrawer(
                    currentUser = currentUser,
                    conversations = conversations,
                    currentConversationId = currentConversation?.id,
                    onSelectConversation = { conv -> viewModel.selectConversation(conv) },
                    onNewChat = { viewModel.newChat() },
                    onRenameConversation = { conv, title -> viewModel.renameConversation(conv, title) },
                    onDeleteConversation = { conv -> viewModel.deleteConversation(conv) },
                    onOpenSettings = {
                        coroutineScope.launch { drawerState.close() }
                        onOpenSettings()
                    },
                    onCloseDrawer = { coroutineScope.launch { drawerState.close() } }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopNavBar(
                    currentConversation = currentConversation,
                    selectedModelId = settings.defaultModel,
                    onSelectModel = { modelId -> viewModel.setDefaultModel(modelId) },
                    onMenuClick = { coroutineScope.launch { drawerState.open() } },
                    onNewChat = { viewModel.newChat() },
                    onRenameConversation = { title ->
                        currentConversation?.let { viewModel.renameConversation(it, title) }
                    },
                    onDeleteConversation = {
                        currentConversation?.let { viewModel.deleteConversation(it) }
                    },
                    onShareConversation = {
                        viewModel.exportChatHistory { transcript ->
                            FileUtils.shareText(context, transcript, "SAMADHAN AI Chat")
                        }
                    }
                )
            },
            bottomBar = {
                Composer(
                    inputPrompt = inputPrompt,
                    onInputChange = { viewModel.setInputPrompt(it) },
                    isGenerating = isGenerating,
                    isImageMode = isImageMode,
                    onToggleImageMode = { viewModel.toggleImageMode() },
                    isListeningVoice = isListeningVoice,
                    onToggleVoiceInput = { viewModel.toggleVoiceInput() },
                    attachedItems = attachedItems,
                    onAddAttachment = { viewModel.addAttachment(it) },
                    onRemoveAttachment = { viewModel.removeAttachment(it) },
                    onSendMessage = { viewModel.sendMessage() },
                    onStopGeneration = { viewModel.stopGeneration() }
                )
            },
            modifier = modifier.fillMaxSize().testTag("main_chat_screen")
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                if (messages.isEmpty()) {
                    // Empty State: Welcome Screen with Suggestion Cards
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 20.dp, vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Spacer(modifier = Modifier.height(20.dp))

                        // Logo
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_samadhan_logo),
                                    contentDescription = "SAMADHAN AI",
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "SAMADHAN AI",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "सिर्फ जवाब नहीं — समाधान।",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "आज मैं आपकी किस समस्या का समाधान कर सकता हूँ?",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 14.sp
                            ),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(32.dp))

                        // 4 Suggestions
                        Box(modifier = Modifier.widthIn(max = 600.dp)) {
                            SuggestionCards(
                                onSelectSuggestion = { suggestionPrompt ->
                                    viewModel.setInputPrompt(suggestionPrompt)
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                } else {
                    // Messages LazyColumn
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 6.dp)
                    ) {
                        items(messages, key = { it.id }) { message ->
                            MessageBubble(
                                message = message,
                                userName = currentUser?.name ?: "User",
                                isSpeaking = isSpeaking && speakingMessageId == message.id,
                                onEdit = { msg -> viewModel.editUserMessage(msg) },
                                onDelete = { msg -> viewModel.deleteMessage(msg) },
                                onRegenerate = { msg -> viewModel.regenerateResponse(msg) },
                                onLike = { msg, liked -> viewModel.likeMessage(msg, liked) },
                                onReadAloud = { msg -> viewModel.speakMessage(msg) }
                            )
                        }

                        if (isGenerating) {
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp),
                                                strokeWidth = 2.dp,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "समाधान तैयार किया जा रहा है...",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
