package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette
val SamadhanPrimaryLight = Color(0xFF0F172A)      // Deep Slate 900
val SamadhanOnPrimaryLight = Color(0xFFFFFFFF)
val SamadhanPrimaryContainerLight = Color(0xFFF1F5F9)
val SamadhanOnPrimaryContainerLight = Color(0xFF0F172A)

val SamadhanSecondaryLight = Color(0xFF2563EB)    // Vibrant Blue Accent
val SamadhanOnSecondaryLight = Color(0xFFFFFFFF)
val SamadhanSecondaryContainerLight = Color(0xFFDBEAFE)
val SamadhanOnSecondaryContainerLight = Color(0xFF1E3A8A)

val SamadhanBackgroundLight = Color(0xFFFFFFFF)
val SamadhanOnBackgroundLight = Color(0xFF0F172A)
val SamadhanSurfaceLight = Color(0xFFFFFFFF)
val SamadhanOnSurfaceLight = Color(0xFF0F172A)
val SamadhanSurfaceVariantLight = Color(0xFFF8FAFC)
val SamadhanOnSurfaceVariantLight = Color(0xFF475569)

val SamadhanOutlineLight = Color(0xFFE2E8F0)
val SamadhanOutlineVariantLight = Color(0xFFCBD5E1)

// Dark Palette
val SamadhanPrimaryDark = Color(0xFFF8FAFC)
val SamadhanOnPrimaryDark = Color(0xFF0F172A)
val SamadhanPrimaryContainerDark = Color(0xFF1E293B)
val SamadhanOnPrimaryContainerDark = Color(0xFFF8FAFC)

val SamadhanSecondaryDark = Color(0xFF60A5FA)
val SamadhanOnSecondaryDark = Color(0xFF0F172A)
val SamadhanSecondaryContainerDark = Color(0xFF1E3A8A)
val SamadhanOnSecondaryContainerDark = Color(0xFFBFDBFE)

val SamadhanBackgroundDark = Color(0xFF0B0F17)
val SamadhanOnBackgroundDark = Color(0xFFF1F5F9)
val SamadhanSurfaceDark = Color(0xFF111827)
val SamadhanOnSurfaceDark = Color(0xFFF1F5F9)
val SamadhanSurfaceVariantDark = Color(0xFF1E293B)
val SamadhanOnSurfaceVariantDark = Color(0xFF94A3B8)

val SamadhanOutlineDark = Color(0xFF334155)
val SamadhanOutlineVariantDark = Color(0xFF1E293B)

// Accent and State Colors
val SamadhanBrandIndigo = Color(0xFF4F46E5)
val SamadhanEmerald = Color(0xFF10B981)
val SamadhanRose = Color(0xFFEF4444)
val SamadhanAmber = Color(0xFFF59E0B)
val CodeBlockBackground = Color(0xFF181C24)
val UserBubbleLight = Color(0xFFF1F5F9)
val UserBubbleDark = Color(0xFF1E293B)
