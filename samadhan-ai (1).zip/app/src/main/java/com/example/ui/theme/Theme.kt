package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = SamadhanPrimaryDark,
    onPrimary = SamadhanOnPrimaryDark,
    primaryContainer = SamadhanPrimaryContainerDark,
    onPrimaryContainer = SamadhanOnPrimaryContainerDark,
    secondary = SamadhanSecondaryDark,
    onSecondary = SamadhanOnSecondaryDark,
    secondaryContainer = SamadhanSecondaryContainerDark,
    onSecondaryContainer = SamadhanOnSecondaryContainerDark,
    background = SamadhanBackgroundDark,
    onBackground = SamadhanOnBackgroundDark,
    surface = SamadhanSurfaceDark,
    onSurface = SamadhanOnSurfaceDark,
    surfaceVariant = SamadhanSurfaceVariantDark,
    onSurfaceVariant = SamadhanOnSurfaceVariantDark,
    outline = SamadhanOutlineDark,
    outlineVariant = SamadhanOutlineVariantDark
)

private val LightColorScheme = lightColorScheme(
    primary = SamadhanPrimaryLight,
    onPrimary = SamadhanOnPrimaryLight,
    primaryContainer = SamadhanPrimaryContainerLight,
    onPrimaryContainer = SamadhanOnPrimaryContainerLight,
    secondary = SamadhanSecondaryLight,
    onSecondary = SamadhanOnSecondaryLight,
    secondaryContainer = SamadhanSecondaryContainerLight,
    onSecondaryContainer = SamadhanOnSecondaryContainerLight,
    background = SamadhanBackgroundLight,
    onBackground = SamadhanOnBackgroundLight,
    surface = SamadhanSurfaceLight,
    onSurface = SamadhanOnSurfaceLight,
    surfaceVariant = SamadhanSurfaceVariantLight,
    onSurfaceVariant = SamadhanOnSurfaceVariantLight,
    outline = SamadhanOutlineLight,
    outlineVariant = SamadhanOutlineVariantLight
)

@Composable
fun MyApplicationTheme(
    themeMode: String = "system", // "system", "light", "dark"
    dynamicColor: Boolean = false, // Keep consistent branding
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        "light" -> false
        "dark" -> true
        else -> isSystemInDarkTheme()
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
