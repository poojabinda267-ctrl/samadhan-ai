package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiModels
import com.example.ai.AiResult
import com.example.ai.GeminiService
import com.example.data.db.AppDatabase
import com.example.data.model.Attachment
import com.example.data.model.Conversation
import com.example.data.model.Message
import com.example.data.model.User
import com.example.data.pref.AppSettings
import com.example.data.pref.UserPreferences
import com.example.data.repository.AuthRepository
import com.example.data.repository.AuthResult
import com.example.data.repository.ChatRepository
import com.example.util.FileUtils
import com.example.util.SpeechHelper
import com.example.util.TtsHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val userPreferences = UserPreferences(application)
    private val authRepository = AuthRepository(db.userDao(), userPreferences)
    private val chatRepository = ChatRepository(db.conversationDao(), db.messageDao())
    private val geminiService = GeminiService(application)
    private val speechHelper = SpeechHelper(application)
    private val ttsHelper = TtsHelper(application)

    // User session
    val currentUser: StateFlow<User?> = authRepository.currentUserFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val settings: StateFlow<AppSettings> = userPreferences.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    // Conversations
    private val _conversations = MutableStateFlow<List<Conversation>>(emptyList())
    val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    private val _currentConversationId = MutableStateFlow<String?>(null)
    val currentConversationId: StateFlow<String?> = _currentConversationId.asStateFlow()

    private val _currentConversation = MutableStateFlow<Conversation?>(null)
    val currentConversation: StateFlow<Conversation?> = _currentConversation.asStateFlow()

    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages: StateFlow<List<Message>> = _messages.asStateFlow()

    // Active Composer state
    private val _inputPrompt = MutableStateFlow("")
    val inputPrompt: StateFlow<String> = _inputPrompt.asStateFlow()

    private val _attachedItems = MutableStateFlow<List<Attachment>>(emptyList())
    val attachedItems: StateFlow<List<Attachment>> = _attachedItems.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _isImageMode = MutableStateFlow(false)
    val isImageMode: StateFlow<Boolean> = _isImageMode.asStateFlow()

    val isListeningVoice: StateFlow<Boolean> = speechHelper.isListening
    val isTtsSpeaking: StateFlow<Boolean> = ttsHelper.isSpeaking
    val speakingMessageId: StateFlow<String?> = ttsHelper.currentlySpeakingMessageId

    private var activeGenerationJob: Job? = null

    init {
        // Observe currentUser to load their conversations
        viewModelScope.launch {
            currentUser.collectLatest { user ->
                if (user != null) {
                    chatRepository.getConversations(user.id).collectLatest { convs ->
                        _conversations.value = convs
                        if (_currentConversationId.value == null && convs.isNotEmpty()) {
                            selectConversation(convs.first())
                        }
                    }
                } else {
                    _conversations.value = emptyList()
                    _currentConversationId.value = null
                    _currentConversation.value = null
                    _messages.value = emptyList()
                }
            }
        }

        // Auto sign-in or seed user if fresh install
        viewModelScope.launch {
            val currentSettings = userPreferences.settingsFlow.first()
            if (currentSettings.currentUserId == null) {
                val authRes = authRepository.continueWithGoogle(
                    userEmail = "poojabinda267@gmail.com",
                    userName = "Pooja Binda"
                )
                if (authRes is AuthResult.Success) {
                    val user = authRes.user
                    val existingConvs = chatRepository.getConversationById("welcome_chat")
                    if (existingConvs == null) {
                        val welcomeConv = chatRepository.createConversation(
                            userId = user.id,
                            title = "नमस्ते! स्वागत है"
                        )
                        chatRepository.insertMessage(
                            Message(
                                id = UUID.randomUUID().toString(),
                                conversationId = welcomeConv.id,
                                role = "assistant",
                                content = """
                                नमस्ते! मैं SAMADHAN AI हूँ।
                                सिर्फ जवाब नहीं — समाधान।
                                आज मैं आपकी किस समस्या में मदद कर सकता हूँ?
                                """.trimIndent(),
                                createdAt = System.currentTimeMillis()
                            )
                        )
                        selectConversation(welcomeConv)
                    }
                }
            }
        }
    }

    // --- Authentication ---
    fun login(email: String, pass: String) {
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null
            when (val result = authRepository.loginWithEmail(email, pass)) {
                is AuthResult.Success -> {
                    _isAuthLoading.value = false
                }
                is AuthResult.Error -> {
                    _isAuthLoading.value = false
                    _authError.value = result.message
                }
            }
        }
    }

    fun signUp(name: String, email: String, pass: String) {
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null
            when (val result = authRepository.signUpWithEmail(name, email, pass)) {
                is AuthResult.Success -> {
                    _isAuthLoading.value = false
                }
                is AuthResult.Error -> {
                    _isAuthLoading.value = false
                    _authError.value = result.message
                }
            }
        }
    }

    fun continueWithGoogle() {
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null
            when (val result = authRepository.continueWithGoogle()) {
                is AuthResult.Success -> {
                    _isAuthLoading.value = false
                }
                is AuthResult.Error -> {
                    _isAuthLoading.value = false
                    _authError.value = result.message
                }
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            ttsHelper.stop()
            speechHelper.stopListening()
            authRepository.logout()
        }
    }

    fun updateUserName(name: String) {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            authRepository.updateName(user, name)
        }
    }

    fun changePassword(newPass: String) {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            authRepository.changePassword(user, newPass)
        }
    }

    fun deleteAccount() {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            chatRepository.deleteAllConversations(user.id)
            authRepository.deleteAccount(user.id)
        }
    }

    // --- Settings ---
    fun setThemeMode(mode: String) {
        viewModelScope.launch { userPreferences.setThemeMode(mode) }
    }

    fun setDefaultModel(modelId: String) {
        viewModelScope.launch { userPreferences.setDefaultModel(modelId) }
    }

    fun setResponseLanguage(lang: String) {
        viewModelScope.launch { userPreferences.setResponseLanguage(lang) }
    }

    fun setStreamingEnabled(enabled: Boolean) {
        viewModelScope.launch { userPreferences.setStreamingEnabled(enabled) }
    }

    fun setVoiceLanguage(lang: String) {
        viewModelScope.launch { userPreferences.setVoiceLanguage(lang) }
    }

    fun setSpeechRate(rate: Float) {
        viewModelScope.launch { userPreferences.setSpeechRate(rate) }
    }

    // --- Conversations & Chat ---
    fun newChat() {
        ttsHelper.stop()
        stopGeneration()
        _currentConversationId.value = null
        _currentConversation.value = null
        _messages.value = emptyList()
        _inputPrompt.value = ""
        _attachedItems.value = emptyList()
        _isImageMode.value = false
    }

    fun selectConversation(conversation: Conversation) {
        ttsHelper.stop()
        stopGeneration()
        _currentConversationId.value = conversation.id
        _currentConversation.value = conversation
        viewModelScope.launch {
            chatRepository.getMessages(conversation.id).collectLatest { msgs ->
                _messages.value = msgs
            }
        }
    }

    fun renameConversation(conversation: Conversation, newTitle: String) {
        viewModelScope.launch {
            chatRepository.updateConversationTitle(conversation.id, newTitle)
            if (_currentConversationId.value == conversation.id) {
                _currentConversation.value = _currentConversation.value?.copy(title = newTitle)
            }
        }
    }

    fun deleteConversation(conversation: Conversation) {
        viewModelScope.launch {
            chatRepository.deleteConversation(conversation.id)
            if (_currentConversationId.value == conversation.id) {
                newChat()
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            chatRepository.deleteAllConversations(user.id)
            newChat()
        }
    }

    fun exportChatHistory(onExportText: (String) -> Unit) {
        val conv = _currentConversation.value ?: return
        val msgs = _messages.value
        val sb = StringBuilder()
        sb.appendLine("SAMADHAN AI - Chat Export: ${conv.title}")
        sb.appendLine("Date: ${java.util.Date(conv.updatedAt)}")
        sb.appendLine("============================================")
        for (m in msgs) {
            val sender = if (m.role == "user") "You" else "SAMADHAN AI"
            sb.appendLine("\n[$sender]:")
            sb.appendLine(m.content)
        }
        onExportText(sb.toString())
    }

    // --- Composer & Message Actions ---
    fun setInputPrompt(text: String) {
        _inputPrompt.value = text
    }

    fun toggleImageMode() {
        _isImageMode.value = !_isImageMode.value
    }

    fun addAttachment(attachment: Attachment) {
        _attachedItems.value = _attachedItems.value + attachment
    }

    fun removeAttachment(attachment: Attachment) {
        _attachedItems.value = _attachedItems.value.filter { it != attachment }
    }

    fun toggleVoiceInput() {
        if (speechHelper.isListening.value) {
            speechHelper.stopListening()
        } else {
            val lang = settings.value.voiceLanguage
            speechHelper.startListening(
                languageCode = lang,
                onResult = { text ->
                    _inputPrompt.value = if (_inputPrompt.value.isEmpty()) text else "${_inputPrompt.value} $text"
                },
                onError = { /* fallback */ }
            )
        }
    }

    fun sendMessage() {
        val text = _inputPrompt.value.trim()
        val currentAttachments = _attachedItems.value
        if (text.isEmpty() && currentAttachments.isEmpty()) return

        val user = currentUser.value ?: return
        val isImgMode = _isImageMode.value
        val modelToUse = settings.value.defaultModel

        // Reset input fields
        _inputPrompt.value = ""
        _attachedItems.value = emptyList()

        activeGenerationJob = viewModelScope.launch {
            // 1. Ensure active conversation
            var activeConv = _currentConversation.value
            if (activeConv == null) {
                val title = if (text.isNotEmpty()) text.take(40) else "New Conversation"
                activeConv = chatRepository.createConversation(user.id, title)
                _currentConversationId.value = activeConv.id
                _currentConversation.value = activeConv
            }

            // 2. Insert User Message
            val attachmentsJson = if (currentAttachments.isNotEmpty()) {
                val arr = JSONArray()
                currentAttachments.forEach {
                    val obj = JSONObject()
                    obj.put("type", it.type)
                    obj.put("name", it.name)
                    obj.put("mimeType", it.mimeType)
                    obj.put("uriString", it.uriString.orEmpty())
                    obj.put("sizeBytes", it.sizeBytes)
                    arr.put(obj)
                }
                arr.toString()
            } else null

            val userMessage = Message(
                id = UUID.randomUUID().toString(),
                conversationId = activeConv.id,
                role = "user",
                content = text,
                createdAt = System.currentTimeMillis(),
                attachmentsJson = attachmentsJson
            )
            chatRepository.insertMessage(userMessage)

            // 3. Prepare AI Message Placeholder
            _isGenerating.value = true
            val aiMessageId = UUID.randomUUID().toString()
            val initialAiMessage = Message(
                id = aiMessageId,
                conversationId = activeConv.id,
                role = "assistant",
                content = "...",
                createdAt = System.currentTimeMillis(),
                modelUsed = if (isImgMode) "gemini-2.5-flash-image" else modelToUse,
                isImageGeneration = isImgMode
            )
            chatRepository.insertMessage(initialAiMessage)

            // Read image bitmap if image attachment exists
            var attachedBitmap: Bitmap? = null
            val imgAttachment = currentAttachments.find { it.type == "image" && it.uriString != null }
            if (imgAttachment != null) {
                try {
                    val uri = Uri.parse(imgAttachment.uriString)
                    val input: InputStream? = getApplication<Application>().contentResolver.openInputStream(uri)
                    attachedBitmap = BitmapFactory.decodeStream(input)
                } catch (_: Exception) {}
            }

            // Read text file content if document attachment exists
            val fileAttachment = currentAttachments.find { it.type == "file" }
            val fileContent = fileAttachment?.textContent

            if (isImgMode) {
                // Generate AI Image
                val result = geminiService.generateAiImage(text)
                when (result) {
                    is AiResult.Success -> {
                        chatRepository.updateMessage(
                            initialAiMessage.copy(
                                content = result.text,
                                generatedImageUri = result.imageUri
                            )
                        )
                    }
                    is AiResult.Error -> {
                        chatRepository.updateMessageContent(aiMessageId, result.message)
                    }
                }
                _isGenerating.value = false
            } else {
                // Regular or Multimodal Chat with n8n Webhook
                val history = _messages.value.map { it.role to it.content }

                val result = geminiService.generateResponse(
                    prompt = text,
                    modelId = modelToUse,
                    conversationHistory = history,
                    imageBitmap = attachedBitmap,
                    fileContent = fileContent,
                    responseLanguage = settings.value.responseLanguage
                )
                when (result) {
                    is AiResult.Success -> {
                        chatRepository.updateMessageContent(aiMessageId, result.text)
                    }
                    is AiResult.Error -> {
                        chatRepository.updateMessageContent(aiMessageId, result.message)
                    }
                }
                _isGenerating.value = false
            }
        }
    }

    fun stopGeneration() {
        activeGenerationJob?.cancel()
        activeGenerationJob = null
        _isGenerating.value = false
    }

    fun regenerateResponse(message: Message) {
        val msgs = _messages.value
        val index = msgs.indexOfFirst { it.id == message.id }
        if (index > 0) {
            val userMsg = msgs[index - 1]
            if (userMsg.role == "user") {
                viewModelScope.launch {
                    chatRepository.deleteMessage(message.id)
                    _inputPrompt.value = userMsg.content
                    sendMessage()
                }
            }
        }
    }

    fun likeMessage(message: Message, isLiked: Boolean) {
        viewModelScope.launch {
            val newLiked = if (message.liked == isLiked) null else isLiked
            chatRepository.updateMessageLiked(message.id, newLiked)
        }
    }

    fun deleteMessage(message: Message) {
        viewModelScope.launch {
            chatRepository.deleteMessage(message.id)
        }
    }

    fun editUserMessage(message: Message) {
        _inputPrompt.value = message.content
        viewModelScope.launch {
            chatRepository.deleteMessage(message.id)
        }
    }

    fun speakMessage(message: Message) {
        val lang = settings.value.voiceLanguage
        val rate = settings.value.speechRate
        ttsHelper.speak(
            messageId = message.id,
            text = message.content,
            languageCode = lang,
            speechRate = rate
        )
    }

    fun testTts() {
        val lang = settings.value.voiceLanguage
        val testText = if (lang.startsWith("hi")) {
            "नमस्ते! मैं समाधान एआई हूँ। सिर्फ जवाब नहीं — समाधान।"
        } else {
            "Hello! I am SAMADHAN AI. Not just an answer, the solution."
        }
        ttsHelper.speak("test_sample", testText, lang, settings.value.speechRate)
    }

    override fun onCleared() {
        super.onCleared()
        speechHelper.stopListening()
        ttsHelper.shutdown()
    }
}
