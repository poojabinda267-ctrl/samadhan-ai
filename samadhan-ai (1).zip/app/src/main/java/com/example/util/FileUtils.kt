package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Attachment
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader

object FileUtils {

    fun copyToClipboard(context: Context, text: String, label: String = "SAMADHAN AI") {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    fun shareText(context: Context, text: String, title: String = "SAMADHAN AI Solution") {
        val sendIntent: Intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, text)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, title)
        context.startActivity(shareIntent)
    }

    fun saveImageToGallery(context: Context, imagePath: String): Boolean {
        try {
            val file = File(imagePath)
            if (!file.exists()) return false

            val bitmap = BitmapFactory.decodeFile(imagePath) ?: return false

            val filename = "SAMADHAN_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/SAMADHAN_AI")
                }

                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { stream ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                    }
                    Toast.makeText(context, "Image saved to Gallery", Toast.LENGTH_SHORT).show()
                    return true
                }
            } else {
                val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val appDir = File(imagesDir, "SAMADHAN_AI")
                if (!appDir.exists()) appDir.mkdirs()
                val destFile = File(appDir, filename)
                FileOutputStream(destFile).use { stream ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                }
                Toast.makeText(context, "Image saved to Pictures/SAMADHAN_AI", Toast.LENGTH_SHORT).show()
                return true
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to save image: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
        return false
    }

    fun shareImage(context: Context, imagePath: String) {
        try {
            val file = File(imagePath)
            val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Image"))
        } catch (_: Exception) {
            // Fallback direct share
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Generated with SAMADHAN AI")
            }
            context.startActivity(Intent.createChooser(sendIntent, "Share"))
        }
    }

    fun extractTextFromFileUri(context: Context, uri: Uri): Attachment? {
        try {
            var fileName = "Document"
            var fileSize = 0L
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) fileName = cursor.getString(nameIndex)
                    if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                }
            }

            val mimeType = context.contentResolver.getType(uri) ?: "text/plain"
            val textBuilder = StringBuilder()

            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).use { reader ->
                    var line: String?
                    var linesRead = 0
                    while (reader.readLine().also { line = it } != null && linesRead < 1000) {
                        textBuilder.appendLine(line)
                        linesRead++
                    }
                }
            }

            val extracted = textBuilder.toString().trim()
            val safeContent = if (extracted.isEmpty()) "File: $fileName ($mimeType)" else extracted

            return Attachment(
                type = "file",
                name = fileName,
                mimeType = mimeType,
                uriString = uri.toString(),
                textContent = safeContent,
                sizeBytes = fileSize
            )
        } catch (e: Exception) {
            return null
        }
    }
}
