package com.example.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

class TtsHelper(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private val _currentlySpeakingMessageId = MutableStateFlow<String?>(null)
    val currentlySpeakingMessageId: StateFlow<String?> = _currentlySpeakingMessageId

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    _currentlySpeakingMessageId.value = null
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    _currentlySpeakingMessageId.value = null
                }
            })
        }
    }

    fun speak(
        messageId: String,
        text: String,
        languageCode: String = "hi-IN",
        speechRate: Float = 1.0f
    ) {
        if (!isInitialized || tts == null) return

        if (_isSpeaking.value && _currentlySpeakingMessageId.value == messageId) {
            stop()
            return
        }

        stop()

        val locale = if (languageCode.startsWith("hi")) {
            Locale("hi", "IN")
        } else {
            Locale.US
        }

        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale.US
        }

        tts?.setSpeechRate(speechRate)

        // Clean markdown symbols for cleaner speech
        val cleaned = text
            .replace(Regex("```[\\s\\S]*?```"), " कोड ब्लॉक ")
            .replace(Regex("[#*`_>~-]"), "")
            .trim()

        _currentlySpeakingMessageId.value = messageId
        _isSpeaking.value = true

        tts?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, messageId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        _currentlySpeakingMessageId.value = null
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }
}
