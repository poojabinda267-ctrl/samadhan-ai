const http = require('http');
const https = require('https');

const PORT = 3000;

// Configuration constants
const LUMOSEL_BASE_HOST = 'api.lumosel.vip';
const LUMOSEL_MESSAGES_PATH = '/v1/messages';
const DEFAULT_MODEL = process.env.LUMOSEL_MODEL || 'claude-opus-5';
const ANTHROPIC_VERSION = '2023-06-01';

const SYSTEM_PROMPT = `You are SAMADHAN AI.

Tagline:
"सिर्फ जवाब नहीं — समाधान।"

Your purpose is to provide helpful, accurate, practical and structured solutions.

Support Hindi, English and Hinglish naturally.

Do not falsely claim actions were performed.

Give direct answers first.

For complex problems, provide structured step-by-step solutions.`;

const fs = require('fs');

function getApiKey() {
  // Check /app/.dev.env.json
  try {
    if (fs.existsSync('/app/.dev.env.json')) {
      const data = JSON.parse(fs.readFileSync('/app/.dev.env.json', 'utf8'));
      if (data && data.LUMOSEL_API_KEY && typeof data.LUMOSEL_API_KEY === 'string') {
        const key = data.LUMOSEL_API_KEY.trim();
        if (key) return key;
      }
    }
  } catch (_) {}

  // Check .env file
  try {
    const envPaths = ['/app/applet/.env', '/app/.env', '.env'];
    for (const p of envPaths) {
      if (fs.existsSync(p)) {
        const lines = fs.readFileSync(p, 'utf8').split('\n');
        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed.startsWith('LUMOSEL_API_KEY=')) {
            const key = trimmed.substring('LUMOSEL_API_KEY='.length).replace(/^["']|["']$/g, '').trim();
            if (key) return key;
          }
        }
      }
    }
  } catch (_) {}

  const key = process.env.LUMOSEL_API_KEY;
  if (!key) return '';
  return key.trim();
}

function mapErrorMessage(statusCode) {
  switch (statusCode) {
    case 401:
      return 'Authentication failed.';
    case 404:
      return 'Model unavailable or incorrect model ID.';
    case 429:
      return 'Usage limit or balance exhausted.';
    case 502:
      return 'Upstream provider temporarily unavailable.';
    case 503:
      return 'Provider temporarily unavailable.';
    default:
      return 'AI service is temporarily unavailable. Please try again later.';
  }
}

function prepareAnthropicPayload(messages, requestedModel, stream) {
  let combinedSystemPrompt = SYSTEM_PROMPT;
  const anthropicMessages = [];

  if (Array.isArray(messages)) {
    for (const msg of messages) {
      if (!msg || typeof msg !== 'object') continue;

      if (msg.role === 'system') {
        const sysText = typeof msg.content === 'string' ? msg.content.trim() : '';
        if (sysText && !combinedSystemPrompt.includes(sysText)) {
          combinedSystemPrompt += `\n\n${sysText}`;
        }
      } else if (msg.role === 'user' || msg.role === 'assistant') {
        const role = msg.role;
        let content = '';
        if (typeof msg.content === 'string') {
          content = msg.content;
        } else if (Array.isArray(msg.content)) {
          content = msg.content.map(c => (c && c.text ? c.text : '')).join('\n');
        } else if (msg.content) {
          content = JSON.stringify(msg.content);
        }

        if (!content.trim()) continue;

        // Anthropic requires strictly alternating user and assistant roles
        if (anthropicMessages.length > 0 && anthropicMessages[anthropicMessages.length - 1].role === role) {
          anthropicMessages[anthropicMessages.length - 1].content += `\n\n${content}`;
        } else {
          anthropicMessages.push({ role, content });
        }
      }
    }
  }

  // Ensure first message is user
  if (anthropicMessages.length === 0 || anthropicMessages[0].role !== 'user') {
    anthropicMessages.unshift({ role: 'user', content: 'Hello' });
  }

  const modelToUse = (requestedModel && requestedModel !== 'default') ? requestedModel : DEFAULT_MODEL;

  return {
    model: modelToUse,
    max_tokens: 2048,
    system: combinedSystemPrompt,
    messages: anthropicMessages,
    stream: Boolean(stream)
  };
}

const server = http.createServer((req, res) => {
  // CORS configuration
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-api-key, anthropic-version');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // Health check endpoint
  if (req.url === '/health' || req.url === '/') {
    const key = getApiKey();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'ok',
      service: 'SAMADHAN AI Backend Gateway',
      provider: 'Lumosel',
      model: DEFAULT_MODEL,
      configured: Boolean(key)
    }));
    return;
  }

  // AI Chat Route
  if (req.url === '/api/chat' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
    });

    req.on('end', () => {
      let parsed;
      try {
        parsed = JSON.parse(body);
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid request JSON.' }));
        return;
      }

      const apiKey = getApiKey();
      if (!apiKey) {
        res.writeHead(503, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'AI service is not configured yet.' }));
        return;
      }

      const { messages, stream, model } = parsed;
      const anthropicPayload = prepareAnthropicPayload(messages, model, stream);
      const payloadString = JSON.stringify(anthropicPayload);

      const makeRequest = (keyAttempt, onResult) => {
        const options = {
          hostname: LUMOSEL_BASE_HOST,
          port: 443,
          path: LUMOSEL_MESSAGES_PATH,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': keyAttempt,
            'anthropic-version': ANTHROPIC_VERSION,
            'Content-Length': Buffer.byteLength(payloadString)
          }
        };

        const upstreamReq = https.request(options, upstreamRes => {
          onResult(null, upstreamRes);
        });

        upstreamReq.on('error', err => {
          onResult(err);
        });

        upstreamReq.write(payloadString);
        upstreamReq.end();
      };

      makeRequest(apiKey, (err, upstreamRes) => {
        if (err) {
          res.writeHead(502, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: mapErrorMessage(502) }));
          return;
        }

        const statusCode = upstreamRes.statusCode || 500;

        // If upstream returns an error (401, 404, 429, 502, 503, etc.)
        if (statusCode >= 400) {
          // If 401 and key contains spaces, test alternative trimmed without internal whitespace
          if (statusCode === 401 && apiKey.includes(' ')) {
            const noSpaceKey = apiKey.replace(/\s+/g, '');
            makeRequest(noSpaceKey, (retryErr, retryRes) => {
              if (!retryErr && retryRes && retryRes.statusCode < 400) {
                handleSuccessResponse(retryRes, stream, res);
                return;
              }
              handleErrorResponse(statusCode, res);
            });
            return;
          }

          handleErrorResponse(statusCode, res);
          return;
        }

        handleSuccessResponse(upstreamRes, stream, res);
      });
    });
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

function handleErrorResponse(statusCode, res) {
  const mapped = mapErrorMessage(statusCode);
  res.writeHead(statusCode, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: mapped }));
}

function handleSuccessResponse(upstreamRes, isStreaming, clientRes) {
  if (isStreaming) {
    clientRes.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive'
    });

    let sseBuffer = '';

    upstreamRes.on('data', chunk => {
      sseBuffer += chunk.toString('utf-8');
      const lines = sseBuffer.split('\n');
      sseBuffer = lines.pop(); // keep last incomplete line

      for (const rawLine of lines) {
        const line = rawLine.trim();
        if (!line) continue;

        if (line.startsWith('data:')) {
          const jsonStr = line.slice(5).trim();
          if (!jsonStr) continue;

          if (jsonStr === '[DONE]') {
            clientRes.write('data: [DONE]\n\n');
            continue;
          }

          try {
            const eventData = JSON.parse(jsonStr);

            // Anthropic content_block_delta
            if (eventData.type === 'content_block_delta' && eventData.delta && typeof eventData.delta.text === 'string') {
              const text = eventData.delta.text;
              const formattedChunk = JSON.stringify({
                choices: [
                  {
                    delta: { content: text }
                  }
                ]
              });
              clientRes.write(`data: ${formattedChunk}\n\n`);
            } else if (eventData.type === 'message_stop') {
              clientRes.write('data: [DONE]\n\n');
            } else if (eventData.choices && eventData.choices[0] && eventData.choices[0].delta) {
              clientRes.write(`data: ${jsonStr}\n\n`);
            }
          } catch (e) {
            // Ignore non-json or keepalive lines
          }
        }
      }
    });

    upstreamRes.on('end', () => {
      clientRes.write('data: [DONE]\n\n');
      clientRes.end();
    });
  } else {
    let body = '';
    upstreamRes.on('data', chunk => {
      body += chunk;
    });

    upstreamRes.on('end', () => {
      try {
        const parsed = JSON.parse(body);
        let textContent = '';

        if (Array.isArray(parsed.content)) {
          for (const block of parsed.content) {
            if (block && block.type === 'text' && typeof block.text === 'string') {
              textContent += block.text;
            }
          }
        } else if (parsed.choices && parsed.choices[0]?.message?.content) {
          textContent = parsed.choices[0].message.content;
        }

        clientRes.writeHead(200, { 'Content-Type': 'application/json' });
        clientRes.end(JSON.stringify({
          choices: [
            {
              message: {
                role: 'assistant',
                content: textContent
              }
            }
          ],
          model: parsed.model || DEFAULT_MODEL,
          usage: parsed.usage || null
        }));
      } catch (e) {
        clientRes.writeHead(500, { 'Content-Type': 'application/json' });
        clientRes.end(JSON.stringify({ error: mapErrorMessage(500) }));
      }
    });
  }
}

server.listen(PORT, () => {
  console.log(`SAMADHAN AI Backend Gateway listening on port ${PORT} (Provider: Lumosel, Model: ${DEFAULT_MODEL})`);
});
